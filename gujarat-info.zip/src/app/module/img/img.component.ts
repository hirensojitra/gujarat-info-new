import { Component } from '@angular/core';
import { ImageApiService } from '../../common/services/image-api.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-img',
  templateUrl: './img.component.html',
  styleUrl: './img.component.scss'
})
export class ImgComponent {
  folders: any[] = [];
  images: any[] = [];
  selectedFile: File | null = null;
  selectedFolderId: number | null = null;
  newFolderName: string = ''; // For adding a new folder
  apiUrl = environment.MasterApi;
  constructor(private imageService: ImageApiService) {}

  ngOnInit() {
    this.fetchFolders();
  }

  // Fetch folders with pagination
  fetchFolders(page: number = 1, limit: number = 10) {
    this.imageService.getFolders(page, limit).subscribe((data: any) => {
      console.log(data)
      this.folders = data.folders;
    });
  }

  // Handle file selection for image upload
  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  // Upload an image to the selected folder
  uploadImage(folderId: number) {
    if (this.selectedFile && folderId) {
      const metadata = { description: 'Sample Image' }; // Example metadata
      this.imageService.uploadImage(folderId, this.selectedFile, metadata).subscribe((response) => {
        console.log('Image uploaded successfully', response);
        this.fetchImages(folderId); // Fetch updated image list
      });
    }
  }

  // Fetch images for a specific folder
  fetchImages(folderId: number, page: number = 1, limit: number = 10) {
    this.imageService.getImagesInFolder(folderId, page, limit).subscribe((data: any) => {
      this.images = data.images;
      this.selectedFolderId = folderId;
    });
  }

  // Delete an image
  deleteImage(folderId: number, imageId: number) {
    this.imageService.deleteImage(folderId, imageId).subscribe((response) => {
      console.log('Image deleted successfully');
      this.fetchImages(folderId); // Refresh image list
    });
  }

  // Add a new folder
  addFolder() {
    if (this.newFolderName.trim()) {
      this.imageService.createFolder(this.newFolderName).subscribe((response) => {
        console.log('Folder created successfully', response);
        this.fetchFolders(); // Refresh folder list
        this.newFolderName = ''; // Clear the input
      });
    }
  }
  async getImage(imageUrl: string, quality?: number, format?: string, thumb?: boolean): Promise<string> {
    try {
      const blob = await this.imageService.getImage(imageUrl, quality, format, thumb).toPromise();
      if (!blob) {
        return 'assets/png/placeholder.png'; // No blob, return placeholder
      }
      const url = window.URL.createObjectURL(blob); // This will only run on the browser
      return url;
    } catch (error) {
      console.error('Error fetching image:', error);
      return 'assets/png/placeholder.png'; // Return the placeholder path on error
    }
  }
  
  
  
}
