
export enum DropDowns {
  NatureofProject=1,
  OrderType=2,
  ItemCategory=3,
  QuarterMaster=4, 
  MilestoneType=5,
  BUMaster=6,
  TaxType=7,
  BUHead=8,
  ProjectSegmentMaster=9, 
  BillingPattern=10,
  ProjectManagerMaster=11
}

