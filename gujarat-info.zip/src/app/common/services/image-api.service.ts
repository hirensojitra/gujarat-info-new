import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ImageApiService {
  private apiUrl = environment.MasterApi; // Adjust this URL as per your server configuration
  constructor(private http: HttpClient) {}
  // Create a new folder
  createFolder(folderName: string): Observable<any> {
    const body = { folderName };
    return this.http.post(`${this.apiUrl}/img/folders`, body);
  }

  // Get folder list with pagination, search, and sorting
  getFolders(page: number = 1, limit: number = 10, search: string = '', sortBy: string = 'created_at', order: string = 'asc'): Observable<any> {
    const params = new HttpParams()
      .set('page', page)
      .set('limit', limit)
      .set('search', search)
      .set('sortBy', sortBy)
      .set('order', order);

    return this.http.get(`${this.apiUrl}/img/folders`, { params });
  }

  // Upload an image to a specific folder
  uploadImage(folderId: number, imageFile: File, metadata: any): Observable<any> {
    const formData = new FormData();
    formData.append('image', imageFile); // File to upload
    formData.append('metadata', JSON.stringify(metadata)); // Additional metadata

    return this.http.post(`${this.apiUrl}/img/folders/${folderId}/images`, formData);
  }

  // Get images within a folder with pagination, search, and sorting
  getImagesInFolder(folderId: number, page: number = 1, limit: number = 10, search: string = '', sortBy: string = 'created_at', order: string = 'asc'): Observable<any> {
    const params = new HttpParams()
      .set('page', page)
      .set('limit', limit)
      .set('search', search)
      .set('sortBy', sortBy)
      .set('order', order);

    return this.http.get(`${this.apiUrl}/img/folders/${folderId}/images`, { params });
  }

  // Delete an image from a folder
  deleteImage(folderId: number, imageId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/img/folders/${folderId}/images/${imageId}`);
  }
  getImage(imageUrl: string, quality?: number, format?: string, thumb?: boolean): Observable<any> {
    let params: any = {};
    if (quality) params.quality = quality.toString();
    if (format) params.format = format;
    if (thumb) params.thumb = 'true';
    return this.http.get(`${this.apiUrl}/img${imageUrl}`, { params, responseType: 'blob' });
  }
}
