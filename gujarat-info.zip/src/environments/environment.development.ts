export const environment = {
  MasterApi: "http://localhost:5000/api/v1",
  // MasterApi: "https://vmi2070714.contaboserver.net/api/v1"
};
