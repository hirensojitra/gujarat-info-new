import { gql } from 'apollo-angular';

export const PLACEHOLDER_QUERY = gql`
  query Placeholder {
    _placeholder
  }
`;