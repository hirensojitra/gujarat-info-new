export interface TokenValidationResponse {
    success: boolean;
    message: string;
}