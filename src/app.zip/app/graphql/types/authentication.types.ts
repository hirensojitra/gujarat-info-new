export interface HasRoleQuery {
  hasRole: boolean;
}

export interface HasRoleVariables {
  user_id: string;
  role_code: string;
}
