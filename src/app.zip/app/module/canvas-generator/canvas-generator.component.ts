// canvas-generator.component.ts
import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-canvas-generator',
  templateUrl: './canvas-generator.component.html',
  styleUrls: ['./canvas-generator.component.scss']
})
export class CanvasGeneratorComponent implements OnInit {
  ngOnInit(): void {
    
  }
}
