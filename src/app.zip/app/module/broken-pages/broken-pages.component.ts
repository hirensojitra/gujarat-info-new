import { Component } from '@angular/core';

@Component({
  selector: 'app-broken-pages',
  templateUrl: './broken-pages.component.html',
  styleUrl: './broken-pages.component.scss'
})
export class BrokenPagesComponent {

}
