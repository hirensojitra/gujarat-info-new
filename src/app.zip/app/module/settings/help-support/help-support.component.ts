import { Component } from '@angular/core';

@Component({
  selector: 'app-help-support',
  templateUrl: './help-support.component.html',
  styleUrl: './help-support.component.scss'
})
export class HelpSupportComponent {

}
