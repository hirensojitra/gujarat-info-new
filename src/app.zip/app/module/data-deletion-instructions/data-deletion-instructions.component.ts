import { Component } from '@angular/core';

@Component({
  selector: 'app-data-deletion-instructions',
  templateUrl: './data-deletion-instructions.component.html',
  styleUrl: './data-deletion-instructions.component.scss'
})
export class DataDeletionInstructionsComponent {

}
