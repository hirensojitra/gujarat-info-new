import { Component } from '@angular/core';

@Component({
  selector: 'app-post-management',
  templateUrl: './post-management.component.html',
  styleUrl: './post-management.component.scss'
})
export class PostManagementComponent {

}
